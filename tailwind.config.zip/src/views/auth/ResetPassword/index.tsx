import ResetPassword from './ResetPassword'

export { ResetPasswordBase } from './ResetPassword'
export default ResetPassword
