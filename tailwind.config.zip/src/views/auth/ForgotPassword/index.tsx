import ForgotPassword from './ForgotPassword'

export { ForgotPasswordBase } from './ForgotPassword'
export default ForgotPassword
