import OtpVerification from './OtpVerification'

export { OtpVerificationBase } from './OtpVerification'
export default OtpVerification
