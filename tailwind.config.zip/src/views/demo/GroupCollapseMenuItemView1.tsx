/** Example purpose only */
const GroupCollapseMenuItemView1 = () => {
    return <div>GroupCollapseMenuItemView1</div>
}

export default GroupCollapseMenuItemView1
