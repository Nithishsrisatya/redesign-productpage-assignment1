/** Example purpose only */
const GroupCollapseMenuItemView2 = () => {
    return <div>GroupCollapseMenuItemView2</div>
}

export default GroupCollapseMenuItemView2
