/** Example purpose only */
const CollapseMenuItemView1 = () => {
    return <div>CollapseMenuItemView1</div>
}

export default CollapseMenuItemView1
