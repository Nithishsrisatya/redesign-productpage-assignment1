export const COLOR_1 = '#2a85ff'
export const COLOR_2 = '#7cbc7d'
export const COLOR_3 = '#ff6a55'
export const COLOR_4 = '#8C62FF'
export const COLOR_5 = '#fbc13e'
export const COLOR_6 = '#00C7BE'
export const COLOR_7 = '#FE964A'
export const COLOR_8 = '#febb7b'
export const COLOR_9 = '#7cd2fa'
export const COLOR_10 = '#bee9d3'

export const COLORS = [
    COLOR_1,
    COLOR_2,
    COLOR_3,
    COLOR_4,
    COLOR_5,
    COLOR_6,
    COLOR_7,
    COLOR_8,
    COLOR_9,
    COLOR_10,
]
