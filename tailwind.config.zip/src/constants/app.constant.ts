export const APP_NAME = 'Ecme'
export const REDIRECT_URL_KEY = 'redirectUrl'
