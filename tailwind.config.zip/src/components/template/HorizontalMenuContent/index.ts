import HorizontalMenuContent from './HorizontalMenuContent'

export default HorizontalMenuContent
