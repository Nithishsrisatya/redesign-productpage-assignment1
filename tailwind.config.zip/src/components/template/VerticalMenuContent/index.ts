import VerticalMenuContent from './VerticalMenuContent'

export type { VerticalMenuContentProps } from './VerticalMenuContent'

export default VerticalMenuContent
