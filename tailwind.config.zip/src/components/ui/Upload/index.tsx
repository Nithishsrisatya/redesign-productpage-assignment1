import Upload from './Upload'

export type { UploadProps } from './Upload'
export { Upload }

export default Upload
