import Tag from './Tag'

export type { TagProps } from './Tag'
export { Tag }

export default Tag
