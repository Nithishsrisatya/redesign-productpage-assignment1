export default function isLastChild(arr: Array<unknown>, index: number) {
    return arr.length === index + 1
}
