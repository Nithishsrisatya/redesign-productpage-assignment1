export { protectedRoutes, publicRoutes } from './routes.config'
